<!DOCTYPE html>
<html>
	<head>
		<title>error | access denied</title>
	<head>
	<body>
		<span style="color:red"><h1>Opps!! Access denied....<br/> Unauthorised Access is not allowed.</h1></span>
		<h3><a href="<?php echo base_url(); ?>/start">Please login</a></h3>
	</body>
</html>